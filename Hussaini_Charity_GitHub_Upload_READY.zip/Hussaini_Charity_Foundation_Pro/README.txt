Hussaini Charity Foundation — Professional starter website
Languages: Dari (default), English, Pashto.
Open index.html to preview.
Before public launch: replace placeholder contact details, verify donation/bank information, add real project/report/gallery content, connect a secure backend and payment provider, and publish a privacy policy/terms.
